

public class Consumer  {
	
	Point pp = new Point(); 
	

	public void consume() {
			
			pp.consumeNum+=1;
			

	}
}
