public class Krabs  {

	Point pp = new Point();
	
	public void produce() {
		
		
		pp.bunPoint++;
			/*
			try {
				Thread.sleep(800);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			 */
			

	}


}
