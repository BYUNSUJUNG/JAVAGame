
public class Point {
	public int pattyPoint=0;
	public int vegetablesPoint=0;
	public int bunPoint=0;
	public int produceNum=0;
	public int consumeNum=0;
}
