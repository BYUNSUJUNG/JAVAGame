
public class Producer  {
	
	Point pp = new Point();

	
	public void produce() {

			
			pp.produceNum+=1;

	}
	
	
}
