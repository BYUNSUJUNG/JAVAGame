
public class JingeriaTest {

	public static void main(String[] args) {	

			JingeriaStart js = new JingeriaStart();


				
	 	/*
			
		if(js.produceSelect==1) { 
			
			 th01.start();
			 js.sbMaterial=sb.Material;
			
			}else if(js.print.equals("cabbage")) {
				th02.start();
				 js.swMaterial=sw.Material;
			} else if(js.print.equals("bun")) {	
				th03.start();
				 js.kkMaterial=kk.Material;
			}
		
		/* public Game() {
			setTitle("Race");
			setSize(600,200);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLayout(null);
			(new MyThread("e:\\img\\1.gif",100,0)).start();
			(new MyThread("e:\\img\\2.gif",100,50)).start();
			(new MyThread("e:\\img\\3.gif",100,100)).start();
			setVisible(true);
		} */
	

	}
}
