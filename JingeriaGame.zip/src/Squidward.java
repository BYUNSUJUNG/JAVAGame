
public class Squidward {

	
	Point pp = new  Point();
	

		
		public void produce() {
			
			
			pp.vegetablesPoint++;
				/*
				try {
					Thread.sleep(800);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				 */


		}

	
}
