package Yakitori;

public class YakitoriScore {

	   static String id;
	   static int score=0;
	   
	   public YakitoriScore() {
		   
	   }
	   
	   public YakitoriScore(String id, int check) {
		   
	   }

}
