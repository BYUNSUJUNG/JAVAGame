
public class JingeriaTest {

	public static void main(String[] args) {
		
			JingeriaStart js = new JingeriaStart();

	}
}
