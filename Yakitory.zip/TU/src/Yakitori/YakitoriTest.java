package Yakitori;

public class YakitoriTest {

	public static void main(String[] args) {
		
		Yakitori ya = new Yakitori();

	}

}
