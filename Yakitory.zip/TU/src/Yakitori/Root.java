package Yakitori;

public interface Root {
   //�մ�
   public void Customer();
   //�丮�ൿ
   public void Cooking();
   //���
   public void Ingredient();
}