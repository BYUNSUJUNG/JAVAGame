package Yakitori;

public interface Root {
   //�մ�
   public void customer();
   //�丮�ൿ
   public void cooking();
   //���
   public void ingredient();
}